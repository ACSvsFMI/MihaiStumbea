<?php

echo "
<link rel='stylesheet' type='text/css' href='".$docroot."css/jquery-ui-1.8.17.custom.css'>
<link rel='stylesheet' type='text/css' href='".$docroot."css/style.css'>

<script type='text/javascript' src='".$docroot."js/jquery-1.7.1.min.js'></script>
<script type='text/javascript' src='".$docroot."js/jquery-ui-1.8.17.custom.min.js'></script>
<script type='text/javascript' src='".$docroot."js/functions.js'></script>
<script type='text/javascript' src='".$docroot."js/map_google.js'></script>
";

?>