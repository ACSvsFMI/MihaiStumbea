<?php

function GetServerStatus($site, $port) {
	$status = array("OFFLINE", "ONLINE");
	$fp = @fsockopen($site, $port, $errno, $errstr, 2);
	if (!$fp) return $status[0];
	else return $status[1];
	}

function MaxID( $table, $col ) {
	$query = "PREPARE GetMaxID0 FROM 'SELECT MAX(".$col.") FROM ".$table."'"; $result = mysql_query($query) or die(mysql_error());
	$query = "EXECUTE GetMaxID0"; $result = mysql_query($query) or die(mysql_error());
	$row = mysql_fetch_array ($result, MYSQL_BOTH);
	$query = "DEALLOCATE PREPARE GetMaxID0"; $resultDeallocate = mysql_query($query) or die(mysql_error());
	return $row[0];
	}

function valid_regex($ptn, $str) {
	preg_match($ptn, $str, $matches);
	if($matches) return true;
	else return false;
	}
	
function showR(){
	echo "<pre>";
	print_r($_REQUEST);
	echo "</pre>";
	}
	
function showS(){
	echo "<pre>";
	print_r($_SESSION);
	echo "</pre>";
	}
	

function ip2bin($ip){
	$bits = explode( ".", $ip);
	$ipbin = '';
	for($i=0; $i<sizeof($bits);$i++){
		if($i) $ipbin .= ".";
		$ipbin .= sprintf("%08s", decbin($bits[$i]));
		}
	return $ipbin;
	}
	
function mask($netmask){
	$mask = '';
	for($i=0; $i<4; $i++){
		if($i) $mask .= ".";
		for($j=0; $j<8; $j++){
			if($netmask) {
				$mask .="1";
				$netmask--;
				}
			else $mask .="0";
			}
		}
	return $mask;
	}

function maskshort($netmask){
	$mask = '0';
	for($i=0; $i<32; $i++){
		if($netmask[$i]) $mask++;
		}
	return $mask;
	}
	
function binshort($ip){
	return str_replace(".", "", $ip);
	}

function bin2ip($ip){
	$bits = str_split($ip, 8);
	$ipbin = '';
	for($i=0; $i<sizeof($bits);$i++){
		if($i) $ipbin .= ".";
		$ipbin .= bindec($bits[$i]);
		}
	return $ipbin;
	}
	
function netstart( $mask, $ip){
	for($k=0; $k<32; $k++){
		if(!$mask[$k]) $ip[$k]='0';
		}
	return $ip;
	}

function broadcast( $mask, $ip){
	for($k=0; $k<32; $k++){
		if(!$mask[$k]) $ip[$k]='1';
		}
	return $ip;
	}
	
function place_subnet($subnet_mask, $nextipid, $lid, $reference){

	global $db;
	
	$search_txt = "SELECT `ipid`, `ipv4` FROM `ip` WHERE `netid`='0' && `ipid`>'".$nextipid."' LIMIT 1";
	$search_sql = mysql_query( $search_txt, $db);
	$search = mysql_fetch_array($search_sql);
	
	if($search[0]){
		$broadcastip = bin2ip(broadcast( binshort(mask($subnet_mask)), binshort(ip2bin(long2ip($search[1])))));
		
		$broadcast_txt = "SELECT `ipid` FROM `ip` WHERE `ipv4`='".ip2long($broadcastip)."' LIMIT 1";
		$broadcast_sql = mysql_query( $search_txt, $db);
		$broadcast = mysql_fetch_array($search_sql);
		
		$range_txt = "SELECT count(*) FROM `ip` WHERE `ipv4` BETWEEN '".$search[1]."' AND '".ip2long($broadcastip)."' && `netid`<>'0' ";
		
		//echo $range_txt;
		
		$range_sql = mysql_query($range_txt, $db);
		$range = mysql_fetch_array($range_sql);
		
		if($range[0]=='0'){
			$place_txt = "UPDATE `ip` SET `netid`='".$search[0]."', `lid`='".$lid."', `mask`='".ip2long(bin2ip(binshort(mask($subnet_mask))))."', `reference`='".$reference."' WHERE `ipv4` BETWEEN '".$search[1]."' AND '".ip2long($broadcastip)."' ";
			$place_sql = mysql_query( $place_txt, $db);
			}
		else {
			place_subnet($subnet_mask, $broadcast[0], $lid);
			}
		//return long2ip($search[1])." - ".bin2ip($broadcast);
		}
	else return "Nu mai exista subnet-uri potrivite libere!";	
	}

function remove_subnet($subnetid){
	global $db;
	$remove_txt = "UPDATE `ip` SET `netid`='0', `lid`='0' WHERE `netid`='".$subnetid."' ";
	$remove_sql = mysql_query( $remove_txt, $db);
	}	
	

?>