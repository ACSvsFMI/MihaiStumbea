<?php

if(isset($_REQUEST['askpswd'])) $askpswd = $_REQUEST['askpswd'];

if ($askuser)
	{
	$result = mysql_query ('SELECT * FROM `users` WHERE `user` = "'.$askuser.'"' , $db);
	if ($good = mysql_fetch_array($result))
		{
		if( $askuser == $good['user'] && md5($askpswd) == $good['passwd'])
			{
			if($good['active'] == '1')
				{
				$authorized = true;

				$member = $good['user'];
				$member_id = $good['id'];
				$member_name = $good['name'];
				
				$_SESSION['member'] = $good['user'];
				$_SESSION['member_id'] = $good['id'];
				$_SESSION['member_name'] = $good['name'];

				$nr=1;
				}
			else
				{
				// user inactiv
				$nr=4;
				}
			}
		else
			{
			// user sau parola gresita
			$nr=3;
			}
		}
	else
		{
		// user inexistent
		$nr=2;
		}
	}
// no user request
else  $nr=0;

?>