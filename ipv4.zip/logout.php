<?php

include('variables.php');

// last request was more than 30 minates ago
$logs_check = mysql_query("SELECT `log_id` FROM `logins` WHERE DATE(`log_date`)=DATE(NOW()) && `user_id`='".$_SESSION['member_id']."' && `log_type`='0' ", $db);
if(!mysql_num_rows($logs_check)){
	$log = mysql_query("INSERT INTO `logins`( `company_id`, `user_id`, `log_type`, `log_date`) VALUES('".$company_id."', '".$_SESSION['member_id']."', '0', NOW())", $db);
	}
else {
	$log_arr = mysql_fetch_array($logs_check);
	$log = mysql_query("UPDATE `logins` SET `log_date`=NOW() WHERE `log_id`='".$log_arr[0]."'", $db);
	}
session_destroy();   // destroy session data in storage
session_unset();     // unset $_SESSION variable for the runtime

?>