<?php

include('connect.php');

$subnet_mask = $_REQUEST['mask'];
$reference = $_REQUEST['reference'];

place_subnet($subnet_mask, '0', '1', $reference);

include('disconnect.php');

?>