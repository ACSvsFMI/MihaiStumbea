<?php

echo "
	</td>
	</tr>
</table>

<table width='100%' border='0' align='center' cellspacing='0' cellpadding='0' bgcolor='#d0d0d0'>
	<tr>
		<td>
			<table width='1100' align='center' border='0' cellspacing='0' cellpadding='4'>
				<tr>
					<td style='padding-left: 10px;'>
						".$member_name."
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>";

?>