<?php

include('connect.php');

$subnetid = $_REQUEST['subnetid'];

echo remove_subnet($subnetid);

include('disconnect.php');

?>