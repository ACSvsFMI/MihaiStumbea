<?php
mysql_close($db);
?>