<?php

include('connect.php');

echo "<table width='100%'><tr><td>Subnets: </td><td></td></tr>";
$search_txt = "SELECT `ipid`, `ipv4`, `mask`, `lid` FROM `ip` WHERE `netid`=`ipid` ";
$search_sql = mysql_query( $search_txt, $db);
while($search = mysql_fetch_array($search_sql)){
	$action = "onclick=\"remove_subnet('".$search['ipid']."')\"";
	
	$broadcastip = bin2ip(broadcast( binshort(ip2bin(long2ip($search['mask']))), binshort(ip2bin(long2ip($search['ipv4'])))));
	echo "
	<tr>
		<td onClick=\"$('#list".$search['ipid']."').toggle(110);\" style='cursor: pointer;'>
			".long2ip($search['ipv4'])." / ".maskshort( binshort(ip2bin(long2ip($search['mask']))))."
			<div id='list".$search['ipid']."' style='position: relative; display:none;  '><div style='top: -50px; position: absolute; border: 1px solid grey; background-color: white;'>".long2ip($search['ipv4'])." - ".$broadcastip."
			</div></div>
		</td>
		<td><input type='button' class='delbtn' title='Remove subnet' ".$action." style='padding-right: 15px;'></td>
	</tr>";
	}
echo "</table>";


include('disconnect.php');

?>