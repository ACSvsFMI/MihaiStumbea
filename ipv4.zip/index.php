<?php

include_once("connect.php");

$key = '';

$gkey_txt = "SELECT `opt_val` FROM `options` WHERE `opt_name`='google_api_key' && `opt_param`='1' LIMIT 1";
$gkey_sql = mysql_query( $gkey_txt, $db);
if($gkey = mysql_fetch_array($gkey_sql)) {
	$google_map = "http://maps.googleapis.com/maps/api/js?key=".$gkey[0]."&amp;sensor=false&libraries=places";
	$key = $gkey[0];
	}
else $google_map = "http://maps.googleapis.com/maps/api/js?sensor=false";
	
if(isset($_REQUEST['askuser']))
	{
	$askuser = $_REQUEST['askuser'];
	include('autentif.php');
	}

echo '
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<title>Google API test</title>
		
			<script type="text/javascript" src="'.$docroot.'js/map_google.js"></script>
			<script type="text/javascript" src="'.$google_map.'"></script>

';

include_once('dependencies.php');

if(isset($member_id))
	{
	echo '
	<script type="text/javascript">
	$(function(){
		site_host = $("#site_host").attr("value");
		key = $("#key").attr("value");
		initialize();
		display_subnets();
	});
	</script>';
	}
	
echo "
</head>
<body>
<div style='display: none;' id='site_host' value='".$docroot."'></div>
<div style='display: none;' id='key' value='".$key."'></div>
";

if(isset($member_id))
	{
	echo "";
	
	include('index_header.php');
	include("page.php");
	include('index_footer.php');

	}
else
	{
	if(!isset($nr)) $nr = 0;
	include('login.php');
	}

//echo "</body></html>";

include('disconnect.php');

?>