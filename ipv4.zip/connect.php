<?php

require_once('variables.php');
$_SESSION['LAST_ACTIVITY'] = time();

?>