<?php

echo "<iframe width='725' height='320' frameborder='1' id='map_iframe' src=''></iframe>";

?>