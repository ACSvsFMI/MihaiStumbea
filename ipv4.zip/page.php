<?php

echo "<input type='text' id='net' name='net' value='' >/<input type='text' id='netmask' name='netmask' value='' size='5'><input type='submit' value='change subnet' onclick=\"update_range();\"><br>";

$location = '';
$lat = '44.429926';
$lng = '26.103473';

echo "
	<input type='hidden' id='start_lat' value='".$lat."'>
	<input type='hidden' id='start_lng' value='".$lng."'>
	<input type='hidden' id='Street' value=''>
	<table width='100%' align='center'>
		<tr>
			<td valign='top'>
				<div id='map_canvas' style='width: 880px; height: 480px;'></div><br>
				<input type='text' name='coord' id='coord' disabled='disabled' value='' style='width: 720px;'>
				<input type='text' name='range' id='range' disabled='disabled' value='10000' style='width: 100px;'>
				<input type='button' class='searchbtn' title='Search' onclick=\"searchReq();\" style='padding-right: 15px;'>";
				//echo "<input type='button' class='addmrk' title='Add Requests' onclick=\"randomPlace();\" style='padding-right: 15px;'>";
				echo "
			</td>
			<td width='200' valign='top'>
				<input type='text' id='subnetmask' name='subnetmask' value='' size='5'><input type='button' class='addbtn' title='Place subnet' onclick=\"place_subnet();\" style='padding-right: 15px;'>
				<div id='subnets' style='overflow-y: scroll; overflow-x: hidden; height: 500px;'></div>
			</td>
		</tr>
  </table>";

?>