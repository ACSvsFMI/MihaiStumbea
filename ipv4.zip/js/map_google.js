var map;
var lastPoint;
var marker;

var geocoder;
var centerChangedLast;
var reverseGeocodedLast;
var currentReverseGeocodeResponse;

function geocode() {
    var address = "Romania, Bucharest";
    geocoder.geocode({
      'address': address,
      'partialmatch': true}, geocodeResult);
  }

function geocodeResult(results, status) {
	if (status == 'OK' && results.length > 0) {
      map.fitBounds(results[0].geometry.viewport);
    }
  }

  function reverseGeocode() {
    reverseGeocodedLast = new Date();
    geocoder.geocode({latLng:map.getCenter()},reverseGeocodeResult);
  }

  function reverseGeocodeResult(results, status) {
    currentReverseGeocodeResponse = results;
    if(status == 'OK') {
      if(results.length == 0) {
        document.getElementById('formatedAddress').innerHTML = 'None';
      } else {
        document.getElementById('formatedAddress').innerHTML = results[0].formatted_address;
      }
    } else {
      document.getElementById('formatedAddress').innerHTML = 'Error';
    }
  }

function initialize() {

	geocoder = new google.maps.Geocoder();
	
	var start_lat = parent.document.getElementById('start_lat').value;
	var start_lng = parent.document.getElementById('start_lng').value;
	
	var myLatlng = new google.maps.LatLng(start_lat, start_lng);
	
	var myOptions = { 
							zoom: 10, 
							center: myLatlng, 
							mapTypeId: google.maps.MapTypeId.ROADMAP 
							};

	map = new google.maps.Map(document.getElementById('map_canvas'), myOptions);

	google.maps.event.addListener( map, 'mousemove', function(point){ lastPoint = point; });
	google.maps.event.addListener( map, 'click', function(event){
		parent.document.getElementById('coord').value = event.latLng.lat().toFixed(7) + ' ' + event.latLng.lng().toFixed(7); 
		parent.document.getElementById('start_lat').value = event.latLng.lat().toFixed(7);
		parent.document.getElementById('start_lng').value = event.latLng.lng().toFixed(7); 
		});
	}
  
function placeMarker(location) {
	if(marker)
		{
		marker.setPosition(location); 
		} 
	else 
		{		
		marker = new google.maps.Marker({
			position: location,
			map: map,
			draggable: true
			});
		}
	}
 
 function getMapCenter(){
	var latLng = map.getCenter();
	parent.document.getElementById('coord').value = latLng.lat().toFixed(7) + ' ' + latLng.lng().toFixed(7); 
	return latLng;
	}
	
function searchReq(){

	var radius = $('#range').attr('value');
	var pos = getMapCenter();
	var JSONurl = 'https://maps.googleapis.com/maps/api/place/nearbysearch/json?location='+pos.lat().toFixed(7) + ',' + pos.lng().toFixed(7) +'&radius='+radius+'&name=HACK&sensor=false&key='+key;
	
	var request = {
    location: pos,
    radius: radius,
    name: "HACK"
		};
	
	service = new google.maps.places.PlacesService(map);
	service.nearbySearch(request, callback)

	}
	
function placeMarker(location, name, reference) {

	marker = new google.maps.Marker({
		position: location,
		title: name,
		map: map,
		draggable: false
		});
	
	infoWindow = new google.maps.InfoWindow();
	google.maps.event.addListener( marker, "click", function() {
		var text = "<div style=\"white-space:nowrap;\"><div align=\"center\" class=\"smalltext\" style=\"cursor: pointer;\" onClick=\"reserve('"+name+"', '"+reference+"')\">"+ name +"</div></div>";
		infoWindow.setContent(text);
		infoWindow.setPosition(location);
		infoWindow.open(map, marker);
        });
	}
	
function callback(results, status) {
  if (status == google.maps.places.PlacesServiceStatus.OK) {
    for (var i = 0; i < results.length; i++) {
      var place = results[i];
      placeMarker(results[i].geometry.location, results[i].name, results[i].reference);
    }
  }
}

function placeTest( latM, lngM, nameM){
	var JSONurl = 'https://maps.googleapis.com/maps/api/place/add/json?sensor=false&key='+key;
	var JSONObject = {
		"location": { "lat": latM, "lng": lngM },
		"accuracy": 50, 
		"name": nameM,
		"types":["accounting"],
		"language":"en"
		};

	alert (JSON.stringify(JSONObject));
	
	var data = JSONObject.serialize();
	
	$.post( JSONurl, data, function(data) {
		alert(data.results);
		}, "json");
	}
	
function randomPlace(){
	//placeTest('44.454369','26.099288',"HACK REQ /30");
	//placeTest('44.464369','26.089288',"HACK REQ /27");
	//placeTest('44.466369','26.086288',"HACK REQ /29");
	//placeTest('44.468369','26.092288',"HACK REQ /29");
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
 