var DHTML = document.getElementById || document.all || document.layers;

function striptag(ob)
	{
	return $(ob).replaceWith( $(ob).html().replace(/<\/?[^>]+>/gi, '') );
	}

function logout()
	{
	if(confirm('Sunteti sigur ca vreti sa iesiti?'))
		{
		dataString = '';
		$.ajax({ type: 'POST', url: site_host+'logout.php', data: dataString, cache: false, success: function(){
			window.location = site_host;
		}});	
		}
	}

function checkboxList( holder, item_class) 
	{ 
	var allVals = [];
	$('.'+item_class).each(function(i) 
		{
		if($(this).attr('checked')=='checked') 
			{
			allVals.push($(this).attr('value'));
			}
		});
 $('#'+holder).attr('value', allVals) ; 
 }

function URLEncode(url){ //Function to encode URL. 
 // Functiile Javascript escape si unescape nu corespund 
 // cu ceea ce fac de fapt browserele... 
	if(url)
		{
		var SAFECHARS = "0123456789" + // Numeric 
		"ABCDEFGHIJKLMNOPQRSTUVWXYZ" + // Alphabetic 
		"abcdefghijklmnopqrstuvwxyz" + 
		"-_.!~*'()"; // RFC2396 Mark characters 
		var HEX = "0123456789ABCDEF";
	 
		var plaintext = url; 
		var encoded = ""; 
		for (var i = 0; i < plaintext.length; i++ ) { 
			var ch = plaintext.charAt(i); 
			if (ch == " ") { 
				encoded += "%20"; // x-www-urlencoded, mai degraba, decat %20 
			} 
			else if (ch == "+") { 
				encoded += "%2B"; // x-www-urlencoded, mai degraba, decat %20 
			} else if (SAFECHARS.indexOf(ch) != -1) { 
				encoded += ch; 
			} else { 
				var charCode = ch.charCodeAt(0); 
				if (charCode > 255) { 
					alert( "Unicode Character '" + ch 
					+ "' cannot be encoded using standard URL encoding.\n" 
					+ "(URL encoding only supports 8-bit characters.)\n" 
					+ "A space (+) will be substituted." ); 
					encoded += "%20"; 
				} else { 
					encoded += "%"; 
					encoded += HEX.charAt((charCode >> 4) & 0xF); 
					encoded += HEX.charAt(charCode & 0xF); 
				} 
			} 
		}
		return encoded; 
		}
	else return '';
	}
 
function URLDecode(url){ //functia decode URL 
 // Inlocuieste + cu ' ' 
 // Inlocuieste %xx cu caracterul echivalent 
 // Trece [ERROR] ca iesire daca %xx nu este valid. 
 var HEXCHARS = "0123456789ABCDEFabcdef"; 
 var encoded = url; 
 var plaintext = ""; 
 var i = 0; 
 while (i < encoded.length) { 
 var ch = encoded.charAt(i); 
 if (ch == "+") { 
 plaintext += " "; 
 i++; 
 } else if (ch == "%") { 
 if (i < (encoded.length-2) 
 && HEXCHARS.indexOf(encoded.charAt(i+1)) != -1 
 && HEXCHARS.indexOf(encoded.charAt(i+2)) != -1 ) { 
 plaintext += unescape( encoded.substr(i,3) ); 
 i += 3; 
 } else { 
 alert( 'Bad escape combination near ...' 
 + encoded.substr(i) ); 
 plaintext += "%[ERROR]"; 
 i++; 
 } 
 } else { 
 plaintext += ch; 
 i++; 
 } 
 } // cat timp returneaza text simplu; 
}

function checkAll(field, item)
	{
	var holder, expform;
	holder = document.getElementById(item);
	expform = document.getElementById(field);
	holder.innerHTML="<div id='checkexp' style='cursor: pointer;' onClick='uncheckAll(\""+field+"\", \""+item+"\");'>Exp</div>";
	for (i = 0; i < expform.elements.length; i++)
		{
		if (expform.elements[i].type === 'checkbox') 
			{
			expform.elements[i].checked = true;
			}
		}
	}

function uncheckAll(field, item)
	{
	var holder, expform;
	holder = document.getElementById(item);
	expform = document.getElementById(field);
	holder.innerHTML="<div id='checkexp' style='cursor: pointer;' onClick='checkAll(\""+field+"\", \""+item+"\");'>Exp</div>";
	for (i = 0; i < expform.elements.length; i++)
		{
		if (expform.elements[i].type === 'checkbox') 
			{
			expform.elements[i].checked = false;
			}
		}
	}

function list_checkbox( holder, checkboxClass, Val){
	var n = new Array();
	$('.'+checkboxClass+':checked').each(function() {
		n.push($(this).attr(Val));
		});
	$("#"+holder).val(n);
	}

function show_map(){
	$('#map_iframe').attr('src', site_host+'map_google.php');
	}
	
function update_range(){

	var netRegex = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
	var netmaskRegex = /^\d+$/;

	var net = $('#net').attr('value');
	var netmask = $('#netmask').attr('value');
	
	if(confirm('This operation RESETS the IP database! Are you sure?'))
		{
		if( netRegex.test(net) && netmaskRegex.test(netmask) && netmask < 31 ){
			dataString = 'net='+net+'&netmask='+netmask;
			$.ajax({ type: 'POST', url: site_host+'net_range.php', data: dataString, cache: false, success: function(re){	if(re) alert(re); }
				});
			}
		else {
			alert('Incorect formats!');
			}
		}
	}

function place_subnet(){
	var netmaskRegex = /^\d+$/;
	var subnet = $('#subnetmask').attr('value');
	if( netmaskRegex.test(subnet) && subnet < 31  ){
		dataString = 'mask='+subnet;
		$.ajax({ type: 'POST', url: site_host+'net_place.php', data: dataString, cache: false, success: function(re){	if(re) alert(re); display_subnets();}
			});	
		}
	else {
		alert('Incorect formats!');
		}
	}

function place_subnet2(subnet, reference){
	dataString = 'mask='+subnet+'&reference='+reference;
	$.ajax({ type: 'POST', url: site_host+'net_place.php', data: dataString, cache: false, success: function(re){	if(re) alert(re); display_subnets();}
		});
	}
	
function remove_subnet(subnetid){
	dataString = 'subnetid='+subnetid;
	$.ajax({ type: 'POST', url: site_host+'net_remove.php', data: dataString, cache: false, success: function(re){	if(re) alert(re); display_subnets();}
		});
	}
	
function display_subnets(){
	$('#subnets').load(site_host+'net_display.php', function(){ });
	}

function reserve(name, reference){
	var n = name.split("/");
	place_subnet2(n[1].trim(), reference);
	}
	

	
	
	
	
	
	