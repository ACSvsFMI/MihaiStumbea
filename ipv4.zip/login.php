<?php

$word['ro'] = array( "Utilizator", "Parola", "Logare", "Va rugam introduceti userul si parola.", "Cont inexistent sau parola gresita!<br> Reincercati!", "Bine ai venit", "Contul dumneavoastra nu este activ. va rugam urmati link-ul din mail-ul de confirmare.", " Administrare cont ", "am <b>uitat user-ul/parola</b>!");
$word['en'] = array( "Username", "Password", "Login", "Please enter your username and password.", "", "Welcome", "Your account is not activ. Please follow the link in the confirmation e-mail.", "< My account >", "i <b>forgot</b> my <b>user/password</b>!");

//echo $_SERVER['HTTP_USER_AGENT'];

if ($nr != 1)
	{
	if ($nr == 0) $top = $word[$lang][3]; // no user
	if ($nr == 2) $top = $word[$lang][4]; // user inexistent
	if ($nr == 3) $top = $word[$lang][4]; // user sau parola gresita
	if ($nr == 4) $top = $word[$lang][6]; // user inactiv
	echo "
	<br><br><br>
	<table class='graybox' width='300' height='130' align='center'>
		<tr>
			<td valign='top' align='center'>
				<br><br>
				<table><tr><td>
					<form action='".$PHP_SELF."' method='post' name='login' >
						<table width='220' align='center'>
							<tr>
								<td width='150'>
									<font class='style1'>".$word[$lang][0]."&nbsp;:&nbsp;</font>
								</td>
								<td width='70'>
									<input type='text' name='askuser' class='box2' style='color:black'>
								</td>
							</tr>
							<tr>
								<td width='150'>
									<font class='style1'>".$word[$lang][1]."&nbsp;:&nbsp;</font>
								</td>
								<td width='70'>
									<input type='password' name='askpswd' class='box2' style='color:black'>
								</td>
							</tr>
						</table>
						<input type='hidden' name='lang' value='".$lang."'>
						<center><p><input type='submit' class='box3' value='".$word[$lang][2]."'></p></center>
					</form>
				</td></tr></table>
			</td>
		</tr>
	</table>
	<br>
	<center><font class='style1'>".$top."</font></center>";
	}
	
?>