<?php

echo "
<table width='100%' border='0' align='center' cellspacing='0' cellpadding='0' bgcolor='white'>
	<tr>
		<td>
			<table width='1150' border='0' align='center' cellspacing='2' cellpadding='0' class='topline'>
				<tr>
					<td align='left' valign='middle' class='bottommenu' style='padding-left: 20px; font-weight: bold;'>
					</td>
					<td style=' font-weight: bold; padding-bottom: 2px;' width='150' align='center'>
						<div class='logout' onclick=\"logout();\" style='cursor: pointer;'>Logout</div>
					</td>
				</tr>
				<tr>
					<td style='bgcolor:white; height: 1024px;' valign='top' align='center' colspan='2'>
						<table width='98%' cellspacing='0' cellpadding='0' align='center' border='0'>
							<tr>
								<td style='padding: 5px;' align='left'>";

?>