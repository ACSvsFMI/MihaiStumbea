<?php

include('connect.php');

$net = $_REQUEST['net'];
$netmask = $_REQUEST['netmask'];

$netbin = ip2bin($net);
$maskbin = mask($netmask);

$netbin_short = binshort($netbin);
$maskbin_short = binshort($maskbin);

$net_broadcast = $netbin_short;
$net_broadcast = broadcast( $maskbin_short, $net_broadcast);

$from = $net;
$to = bin2ip($net_broadcast);

$start = ip2long($from);
$end = ip2long($to);
$range = range($start, $end);

$empty_txt = "TRUNCATE `ip`";
mysql_query( $empty_txt, $db);

$insert_txt = "INSERT INTO `ip`(`ipv4`, `mask`, `netid`, `lid`, `type`, `di`) VALUES ";
for($i=0; $i< sizeof($range); $i++){
	if($i) $insert_txt .= ", ";
	$insert_txt .= "( '".$range[$i]."', '".ip2long(bin2ip(binshort($maskbin)))."', '0', '0', '0', NOW() )";
	}
mysql_query( $insert_txt, $db);

include('disconnect.php');

?>