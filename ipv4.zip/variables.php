<?php

session_start();
header('Content-type: text/html; charset=utf-8');

if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 60*60)) {
    // last request was more than 30 minates ago
    session_destroy();   // destroy session data in storage
    session_unset();     // unset $_SESSION variable for the runtime
	}

if (!isset($_SESSION['CREATED'])) {
    $_SESSION['CREATED'] = time();
	} 
else if (time() - $_SESSION['CREATED'] > 60*60) {
    // session started more than 20 minutes ago
    session_regenerate_id(true);    // change session ID for the current session and invalidate old session ID
    $_SESSION['CREATED'] = time();  // update creation time
	}

$lang='ro';

$ipaddr = $_SERVER['REMOTE_ADDR'];
$useragent = $_SERVER['HTTP_USER_AGENT'];
$PHP_SELF = $_SERVER['PHP_SELF'];
$self = $_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING'];
$directory_self = 'http://'.$_SERVER['HTTP_HOST'] .str_replace(basename($_SERVER['PHP_SELF']), '', $_SERVER['PHP_SELF']);

$docroot = "http://".$_SERVER['SERVER_NAME'].dirname($_SERVER['PHP_SELF'])."/";

date_default_timezone_set('Europe/Bucharest');

require_once("config.php");
require_once("functions.php");

$db = mysql_connect($db_server,$db_user,$db_password) or die("Fatal Error: ".mysql_error());
mysql_select_db($db_name, $db) or die(mysql_error());

if(isset($_SESSION['member']))
	{
	$member = $_SESSION['member'];
	$member_id = $_SESSION['member_id'];
	$member_name = $_SESSION['member_name'];
	}

$div_on = "<div class='check_on' style='float: left;'> </div>";
$div_off = "<div class='check_off' style='float: left;'> </div>";

?>