<?php

// jSON URL which should be requested
$url = $_REQUEST['url'];
$location = $_REQUEST['location'];
$radius = $_REQUEST['radius'];
$name = $_REQUEST['name'];
$key = $_REQUEST['key'];
 
// $username = 'your_username';  // authentication
// $password = 'your_password';  // authentication
 
$json_url = $url."?location=".$location."&radius=".$radius."&name=".$name."&sensor=false&key=".$key;
 
 echo $json_url."<br>";
 
var dataObj = null; 

Ext.Ajax.request({ 
    url: $json_url, 
    failure: function(response, options) {}, 
    success: function(response, options) { 
        //assuming the response is a JSON string... 
        dataObj = Ext.decode(response.responseText); 

        //add any other logic you want here 
    } 
});












?>